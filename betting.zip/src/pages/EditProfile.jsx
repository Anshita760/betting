import React from 'react'

const EditProfile = () => {
  return (
    <div>
      
    </div>
  )
}

export default EditProfile
